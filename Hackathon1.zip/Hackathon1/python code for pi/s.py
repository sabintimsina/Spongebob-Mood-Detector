#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Sat Sep 23 12:40:04 2017

@author: aaronstoeger
"""

happiness = 0

A = 0
B = 0

num = raw_input("Who do you think will win the egg bowl? \n A. Olemiss \n B. Mississippi State \n Answer:")

if num == "A":
    happiness += 1
elif num == "B":
    happiness -= 1

num = raw_input("Cow bell? \n A. Less \n B. More  \n Answer: ")

if num == "A":
    happiness += 1
elif num == "B":
    happiness -= 1
elif num=='C':
    happiness+=0
num = raw_input("My favorite animal is? \n A. Land Shark \n B. Bulldog  \n Answer:")

if num == "A":
    happiness += 1
elif num == "B":
    happiness -= 1

num = raw_input("Favorite motto? \n A.Hotty Toddy \n B.Hail State \n C. I code and I know things")

if num == "A":
    happiness += 1
elif num == "B":
    happiness -= 1

num = raw_input("Who's the better bulldog? \n A. Uga X   \n B. Bully \n Answer:")

if num == "A":
    happiness += 1
elif num == "B":
    happiness -= 1

# print happiness


if happiness > 4:
    print
    "\n happy"

elif happiness >= 4:
    print
    "\n ok"
elif happiness == 3:
    print
    "\n surprised"
elif happiness <= 2:
    print
    "\n sad"

