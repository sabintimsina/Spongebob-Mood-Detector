from tkinter import*
from tkinter import messagebox
from PIL import ImageTk,Image
import time
import os
import sys
import serial
import time
import re

def restart_program():
    """Restarts the current program.
    Note: this function does not return. Any cleanup action (like
    saving data) must be done before calling this function."""
    python = sys.executable
    os.execl(python, python, * sys.argv)

def window():
    root=Tk()
    root.geometry('700x500')
    root.wm_title("Spongebob Mood Detector")

    #background_image = ImageTk.PhotoImage(file="flower.jpg")
    #background_label = Label(root, image=background_image, fg="red")
    #background_label.place(x=0, y=0, relwidth=1, relheight=1)
    #root.lift()
    # background_label.pack()'''

    topframe = Frame(root)
    topframe.pack()
    bottomframe = Frame(root)
    bottomframe.pack(side=BOTTOM)
    var = IntVar()
    var1=IntVar()
    # abc="ROBOCARE"

    sabin1 = Label(text="Are you happy?\n", font="Times 12")
    sabin1.pack()
    #button1 = Button( root,text="Quit", command=makeSomething(2,b,c,d), highlightbackground="BLACK").pack()


    var3 = IntVar()
    var4 = IntVar()


    c1=Checkbutton(root, text="Yes ", variable=var)
    c1.grid(row=6);
    c1.pack()
    c2 = Checkbutton( root,text="No",variable=var1)
    c2.grid(row=4);
    c2.pack()


    sabin2= Label(text="Are you happy?\n", font="Times 12")
    sabin2.pack()

    c3 = Checkbutton(root, text="Yes ", variable=var3)
    c3.grid(row=8);
    c3.pack()
    c4 = Checkbutton(root, text="No", variable=var4)
    c4.grid(row=10);
    c4.pack()
    asd=[]
    def das():
        if(len(asd)==0):
           asd.append(1)
        elif (len(asd)==1):
           asd.append(1)
        elif (len(asd) == 2):
            asd.append(1)
        elif (len(asd) == 3):
            asd.append(1)

        else:
            sabin4 = Label(text="error", font="Times 12")
            sabin4.pack()
        print(asd)

        sabin3 = Label(text="done", font="Times 12")
        sabin3.pack()
        root.update()
    button3 = Button(topframe, text="Restart", highlightbackground="BLACK",command=das)

    button3.pack(side=RIGHT, fill=X, expand=True)
    root.update()


    root.mainloop()
    #
    # # Sabin.pack(fill=X)
    # Sabin1 = Label(topframe, bg="BLACK", text="Hey,\nI am Robo Temp. I can measure Surrounding temperature \n",
    #                fg="#c6e6fe", font="Times 18")
    # Sabin1.pack(fill=X)
    #
    # root.update()
    # import Welcome
    # Welcome
    #
    # Sabin7 = Label(topframe, bg="BLACK", text=" Press the Button if you want to measure current temperature ",
    #                fg="#c6e6fe", font="Times 18", borderwidth=2, relief="groove")
    #
    # Sabin7.pack(fill=X)
    # root.update()
    # button()
    # send()
    #
    # '''Sabin3 = Label(topframe, text="Your measured temperature is displayed below:",  fg="#c6e6fe",bg="BLACK", font= "Times 20")
    #
    # Sabin3.pack(fill=X)
    # root.update()
    # import Temp
    # Temp'''
    #
    # Sabin4 = Label(topframe, text="Measuring....\n", fg="#c6e6fe", bg="BLACK", font="Times 9")
    # Sabin4.pack(fill=X)
    # root.update()
    #
    # Sabin5 = Label(topframe, text=receive(), fg="#fd8275", bg="BLACK", font="Times 30")
    # Sabin5.pack(fill=X)
    # root.update()
    #
    # time.sleep(0.5)
    # Sabin10 = Label(topframe, text="\n", fg="#c6e6fe", bg="black", font="Times 13")
    # Sabin10.pack(fill=X)
    # root.update()
    #
    # # Sabin.grid(row=0,sticky=E)
    # # Sabin1.grid(row=1,sticky=E)
    # # entry_1.grid(row=0,column=2,sticky=E)
    # # a=Checkbutton(root, text="tick")
    # # a.grid(columnspan=3)'''
    # '''topframe= Frame(root)
    # topframe.pack()
    # bottomframe=Frame(root)
    # bottomframe.pack(side=BOTTOM)
    # button5=Button(topframe,text="Click1",fg="red")
    # button1=Button(topframe,text="click2",fg="blue")
    # button2=Button(topframe,text="click3", fg="green")
    # button3=Button(bottomframe,text="click4", fg="purple")
    # button5.pack(side=RIGHT)
    # button1.pack(side=RIGHT)
    # button2.pack(side=RIGHT)
    # button3.pack(side=RIGHT)'''
    #
    # button2 = Button(topframe, text="Quit", command=topframe.quit, highlightbackground="BLACK")
    # # Rtopframe.destroy()
    #
    # button3 = Button(topframe, text="Restart", highlightbackground="BLACK", command=restart_program)
    # button2.pack(fill=X, expand=True, side=LEFT)
    # button3.pack(side=RIGHT, fill=X, expand=True)
    # print(button3)
    # # for child in topframe.winfo_children():
    # # child.destroy()'''
    # root.mainloop()
    #
    #
    #
    #
    #
    #

window()