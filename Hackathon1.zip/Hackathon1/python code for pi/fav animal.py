import time
import pygame
pygame.mixer.init(frequency=22050, size=-16, channels=2, buffer=4096)
pygame.mixer.music.load("fav animal.mp3")
pygame.mixer.music.play()
time.sleep(2)