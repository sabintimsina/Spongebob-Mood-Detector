from tkinter import *
from tkinter import messagebox
from PIL import ImageTk, Image
import time
import os
import sys
import serial
import time
import re


def restart_program():
    """Restarts the current program.
    Note: this function does not return. Any cleanup action (like
    saving data) must be done before calling this function."""
    python = sys.executable
    os.execl(python, python, *sys.argv)


root = Tk()
root.geometry('800x620')
root.wm_title("Spongebob Mood Detector")

topframe = Frame(root)
topframe.pack()
bottomframe = Frame(root)
bottomframe.pack(side=BOTTOM)
notify1 = Label(root, text="Type 'A' 'B' 'C' for resprnce", font="Times 12")
notify1.pack(anchor=CENTER)
sabin1 = Label(root, text="Who do you think will win the egg bowl? \n A. Olemiss  B. Mississippi State  C. I dont care",
               font="Times 14")
sabin1.pack()
root.update()
import whoeggbowl
whoeggbowl

# name = input("What's your name? ")
# print("Nice to meet you " + name + "!")
name = StringVar()
e1 = Entry(root, textvariable=name)
# e1.grid(row=2, column=1)
e1.pack()
sabin2 = Label(root, text="Cow bell? \n A. Less  B. More  C.Dont want any: ", font="Times 14")
sabin2.pack()
root.update()
import cowbeel
cowbeel

name1 = StringVar()
e2 = Entry(root, textvariable=name1)
# e2.grid(row=5, column=1)
e2.pack()
# sabin3 = Label(root,text="My favorite animal is? \n A. Land Shark B. Bulldog :", font="Times 14")
# sabin3.pack()

# root.update()

# name2=StringVar()
# e3 = Entry(root,textvariable=name2)
# e3.grid(row=8, column=1)
# e3.pack()
sabin4 = Label(root, text="Favorite football motto? \n A.Hotty Toddy  B.Hail State  C.I code and I know things",
               font="Times 14")
sabin4.pack()

root.update()
import football
football


name3 = StringVar()
e4 = Entry(root, textvariable=name3)
# e4.grid(row=11, column=1)
e4.pack()

sabin5 = Label(root, text="Whom are you talking with \n A.Robot  B.Dont care C.My Mirror image", font="Times 14")
sabin5.pack()
root.update()
import whomtalking
whomtalking

name4 = StringVar()
e5 = Entry(root, textvariable=name4)
# e5.grid(row=13, column=1)
e5.pack()
time.sleep(1)

import please
please

def doit():
    count = 0
    count1 = 0
    count2 = 0
    count3 = 0
    count4 = 0
    count5 = 0
    count6 = 0
    count7 = 0
    count8 = 0
    count9 = 0
    count10 = 0
    count11 = 0
    count12 = 0
    count13 = 0
    yes = 'A'
    no = 'B'
    next = 'C'
    if (str(name.get()).upper() == yes):
        count = count + 1
    if (str(name.get()).upper() == no):
        count1 = count1 + 1
    if (str(name.get()).upper() == next):
        count2 = count2 + 1
    if (str(name1.get()).upper() == yes):
        count3 = count3 + 1
    if (str(name1.get()).upper() == no):
        count4 = count4 + 1
    if (str(name1.get()).upper() == next):
        count5 = count5 + 1
        # if (str(name2.get()).upper()== yes ):
        #    count6=count6+1
        # if (str(name2.get()).upper()== no):
        #   count7=count7+1
    if (str(name3.get()).upper() == yes):
        count8 = count8 + 1
    if (str(name3.get()).upper() == no):
        count9 = count9 + 1
    if (str(name3.get()).upper() == next):
        count10 = count10 + 1
    if (str(name4.get()).upper() == yes):
        count11 = count11 + 1
    if (str(name4.get()).upper() == no):
        count12 = count12 + 1
    if (str(name4.get()).upper() == next):
        count13 = count13 + 1
    s = (count * 1 + count1 * (-1) + count2 * 0 + count3 * 0 + count4 * 0 + count5 * (
    -1) + count8 * 1 + count9 * 0 + count10 * 2 + count11 * 0 + count12 * (-1) + count13 * (1))
    print(s)
    doit.a = 0
    if (count13 == 1 or count10 == 1):
        doit.a = 1  # surprised
        sabin6 = Label(root, text="You seem to be Surprised. Was it because of me?",
                       font="Times 14")
        sabin6.pack()
        root.update()
        send()
        import bazinga
        bazinga
        import surprised
        surprised

    elif (s > 1):
        doit.a = 2  # happy
        sabin7 = Label(root, text="You seem to be happy.Hmm something must be going on",
                       font="Times 14")
        sabin7.pack()
        root.update()
        send()
        import drum
        drum
        import happy
        happy
    elif (s <= 1 and s > -1):
        doit.a = 3  # awesome
        sabin8 = Label(root, text="Ohh you are an awesome person! Dabb",
                       font="Times 14")
        sabin8.pack()
        root.update()
        send()
        import drum
        drum
        import dabb
        dabb

    elif (s <= -1):

        doit.a = 4  # sad
        sabin9 = Label(root, text="Hey talk with my Friend Sabin. He can make you feel a lot better\n",
                       font="Times 14")

        sabin9.pack()
        root.update()
        send()
        import feelbetter
        feelbetter
        import sad
        sad
    print(s)
    print(count10)
    print(count13)
    



def send():
    c = str(doit.a)
    ser = serial.Serial('/dev/ttyS0', 9600)
    x = bytearray(c.encode())
    ser.write(x)


button3 = Button(root, text="Done", highlightbackground="BLACK", command=doit)
button3.pack(side=RIGHT, expand=True)
button6 = Button(bottomframe, text="Quit", command=topframe.quit, highlightbackground="BLACK")
button7 = Button(bottomframe, text="Restart", highlightbackground="BLACK", command=restart_program)
button6.pack(side=RIGHT, fill=X, expand=True)
button7.pack(side=RIGHT, fill=X, expand=True)
root.mainloop()
