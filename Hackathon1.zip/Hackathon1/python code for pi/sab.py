from tkinter import*
from tkinter import messagebox
from PIL import ImageTk,Image
import time
import os
import sys
import serial
import time
import re
def window():
    root=Tk()
    root.geometry('700x500')
    root.wm_title("Spongebob Mood Detector")
    topframe = Frame(root)
    topframe.pack()
    bottomframe = Frame(root)
    bottomframe.pack(side=BOTTOM)
    var = IntVar()
    var1=IntVar()
    root.update()
    c=Checkbutton(root, text="On", variable=var1, onvalue=1, offvalue=0, height=1, width=10, anchor=W)
    c.grid(row=4, column=2)
    c.pack()
    c2 = Checkbutton(root, text="No")
    c2.grid(row=4);
    c2.pack()

    print(var1.get())
    root.mainloop()
    root.exit()
    while True:
        if (var1.get()==1):
            print("a")

window()